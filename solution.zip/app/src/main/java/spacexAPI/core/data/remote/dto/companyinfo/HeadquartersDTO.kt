package spacexAPI.core.data.remote.dto.companyinfo

data class HeadquartersDTO(
    val address: String,
    val city: String,
    val state: String
)