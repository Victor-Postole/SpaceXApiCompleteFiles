package spacexAPI.core.data.remote.dto.companyInfo

data class Links(
    val elon_twitter: String,
    val flickr: String,
    val twitter: String,
    val website: String
)