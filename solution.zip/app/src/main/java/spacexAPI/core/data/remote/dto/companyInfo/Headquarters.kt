package spacexAPI.core.data.remote.dto.companyInfo

data class Headquarters(
    val address: String,
    val city: String,
    val state: String
)