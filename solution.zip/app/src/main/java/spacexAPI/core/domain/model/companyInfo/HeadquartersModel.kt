package spacexAPI.core.domain.model.companyInfo

data class HeadquartersModel(
    val address: String,
    val city: String,
    val state: String
)