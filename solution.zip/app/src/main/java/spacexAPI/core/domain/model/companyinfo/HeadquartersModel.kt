package spacexAPI.core.domain.model.companyinfo

data class HeadquartersModel(
    val address: String,
    val city: String,
    val state: String
)