package spacexAPI.core.domain.model.companyInfo

data class LinksModel(
    val elon_twitter: String,
    val flickr: String,
    val twitter: String,
    val website: String
)